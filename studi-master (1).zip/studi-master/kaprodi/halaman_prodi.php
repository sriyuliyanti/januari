<!DOCTYPE html>
<?php
	include_once('header_prodi.php');
?>		
<div class="container" style="margin-top:40px">
</br/>
  <h1> Selamat Datang Di Halaman Utama Kaprodi</h1>

 		<img style='height: 200px; margin-top: -1px' src='../assets/img/icon/prodi.png' class='img-circle'>
</div>				
