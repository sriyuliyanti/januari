<?php
include_once('header_admin.php');
?>

		
<div class="container" style="margin-top:40px">
 		<h1> Selamat Datang Di Halaman Utama Admin</h1>

 		<img style='height: 200px;' src='../assets/img/icon/admin.png' class='img-circle'>


 </div>				
